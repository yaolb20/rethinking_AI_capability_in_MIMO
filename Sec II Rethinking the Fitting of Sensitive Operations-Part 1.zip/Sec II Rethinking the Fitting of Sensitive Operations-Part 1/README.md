This is the first part of the source code of Section II: Rethinking the Fitting of Sensitive Operations
1. Due to storage restriction of Github, datasets, checkpoints and simulation records can be downloaded from Tsinghua Cloud:
https://cloud.tsinghua.edu.cn/d/7ada451e1d6c462f8555/
2. The folder is free to use, including dataset utilization, simulation result reproduction, model improvement, etc.
3. For academic use, please cite the reference below:
K. Ma, L. Yao, et al., Rethinking the Capabilities of Deep Learning in MIMO Systems: Case Studies and Opportunities, submitted to IEEE, to be uploaded in Arxiv.
4. Run `utils/data_generation.py` to generate the data. 
Run `main.py` to train and evaluate the model. 
The parameters could be set by modifying the corresponding lines in `main.py`.
Run `fig1.m` to generate figure 1.