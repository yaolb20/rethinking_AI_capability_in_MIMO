'''
 @ File: basemodel.py
 @ Time: (UTC+8) 2023/11/03 15:01:57
 @ Description: The base model for CSI matrix inversion fitting
'''
import torch.nn as nn


class BaseModel(nn.Module):
    def __init__(self):
        super(BaseModel, self).__init__()

    def forward(self, x):
        raise NotImplementedError(
            "Subclasses must implement the forward method.")
