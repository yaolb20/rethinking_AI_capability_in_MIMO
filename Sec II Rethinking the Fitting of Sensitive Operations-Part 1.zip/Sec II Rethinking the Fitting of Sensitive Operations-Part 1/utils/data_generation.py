'''
 @ File: data_generation.py
 @ Time: (UTC+8) 2023/11/01 21:55:11
 @ Description: Generate M*N CSI matrices with condition number cond
'''
import numpy as np


def data_generation(M, N, cond, num, path):
    """Call this function to generate num M*N CSI matrices with condition number cond

    Args:
        M (int): row number of matrix
        N (int): column number of matrix
        cond (float): condition number of matrix
        num (int): the number of matrices
        path (str): path to save data

    Returns:
        np.array: num*M*N, CSI matrices
        np.array: num*M*N, the Pseudo-inverse of the CSI matrices (note that this is not used in the simulation, just for the future work)
    """

    channel = np.zeros((num, M, N), dtype=complex)
    label = np.zeros((num, M, N), dtype=complex)
    # generate random complex Gaussian matrices and set their singular values manually to control the condition number
    A = np.random.randn(num, M, N) + 1j * np.random.randn(num, M, N)
    for i in range(num):
        # apply SVD to the matrices and replace the singular values with the desired ones
        U, S, V_H = np.linalg.svd(A[i, :, :], full_matrices=False)
        S = np.logspace(0, np.log10(cond), min(M, N))
        channel[i, :, :] = np.matmul(U, np.matmul(np.diag(S), V_H))
        # normalize the matrix to keep its Frobenius norm as 1
        channel[i, :, :] = channel[i, :, :] / np.linalg.norm(channel[i, :, :])
        # calculate the Pseudo-inverse of the matrices
        label[i, :, :] = np.matrix.getH(np.linalg.pinv(channel[i, :, :]))
    np.savez(path, channel=channel, label=label)
    return channel, label


if __name__ == "__main__":
    # generate CSI matrix with different condition number
    # 180000 matrices for training and 20000 matrices for evaluation
    data_generation(32, 5, 1, 180000,
                    "./data/train/32_5_1_train.npz")
    data_generation(32, 5, 1, 20000,
                    "./data/eval/32_5_1_eval.npz")
    data_generation(32, 5, 10, 180000,
                    "./data/train/32_5_10_train.npz")
    data_generation(32, 5, 10, 20000,
                    "./data/eval/32_5_10_eval.npz")
    data_generation(32, 5, 100, 180000,
                    "./data/train/32_5_100_train.npz")
    data_generation(32, 5, 100, 20000,
                    "./data/eval/32_5_100_eval.npz")
    data_generation(32, 5, 1000, 180000,
                    "./data/train/32_5_1000_train.npz")
    data_generation(32, 5, 1000, 20000,
                    "./data/eval/32_5_1000_eval.npz")
    data_generation(32, 5, np.sqrt(10), 180000,
                    "./data/train/32_5_sqrt10_train.npz")
    data_generation(32, 5, np.sqrt(10), 20000,
                    "./data/eval/32_5_sqrt10_eval.npz")
    data_generation(32, 5, 10 * np.sqrt(10), 180000,
                    "./data/train/32_5_10sqrt10_train.npz")
    data_generation(32, 5, 10 * np.sqrt(10), 20000,
                    "./data/eval/32_5_10sqrt10_eval.npz")
    data_generation(32, 5, 100 * np.sqrt(10), 180000,
                    "./data/train/32_5_100sqrt10_train.npz")
    data_generation(32, 5, 100 * np.sqrt(10), 20000,
                    "./data/eval/32_5_100sqrt10_eval.npz")
