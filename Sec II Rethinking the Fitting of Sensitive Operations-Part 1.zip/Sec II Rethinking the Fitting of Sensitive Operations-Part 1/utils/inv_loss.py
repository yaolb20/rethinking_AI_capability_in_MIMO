'''
 @ File: inv_loss.py
 @ Time: (UTC+8) 2023/12/30 12:02:10
 @ Description: Calculate the mean square error between the predicted inverse matrix multiplied by the original matrix and the identity matrix as the inverse loss.
'''
import torch


def inv_loss(H, V):
    """Calculate the mean square error between the predicted inverse matrix multiplied by the original matrix and the identity matrix.

    Args:
        H (torch.Tensor): channel, complex tensor with shape (batch, M, N)
        V (torch.Tensor): inverse matrix complex tensor with shape (batch, M, N)

    Returns:
        float: inverse loss
    """

    # matrix multiplication
    HV = torch.matmul(torch.conj(torch.transpose(H, -2, -1)), V)
    # calculate the mean square error
    HV = HV - \
        torch.eye(HV.shape[-1], device=HV.device).reshape(1,
                                                          HV.shape[-1], HV.shape[-1])
    loss = torch.norm(HV, dim=(-2, -1))
    loss = torch.mean(loss)
    return loss
