'''
 @ File: eval.py
 @ Time: (UTC+8) 2023/11/03 16:49:02
 @ Description: Evaluate the model
'''
import torch
from utils.inv_loss import inv_loss


def eval(model, test_loader):
    """Evaluate the model

    Args:
        model (torch.nn.Module): the DNN model
        test_loader (torch.utils.data.DataLoader): data loader for testing
        criterion (torch.nn): loss function

    Returns:
        float: average loss
    """

    model.eval()
    running_loss = 0
    with torch.no_grad():
        for _, (channel, _) in enumerate(test_loader):
            output = model(channel)
            loss = inv_loss(channel, output)
            running_loss += loss.item()
    return running_loss / len(test_loader)
