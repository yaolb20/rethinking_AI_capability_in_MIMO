'''
 @ File: dataset.py
 @ Time: (UTC+8) 2023/11/03 11:20:31
 @ Description: Read data from .npz files and create dataset
'''
import numpy as np
import torch
from torch.utils.data import Dataset


class MatDataset(Dataset):
    def __init__(self, path, device='cuda:0' if torch.cuda.is_available() else 'cpu'):
        """Read data from .npz files

        Args:
            path (str): path to .npz files
            batch_size (int, optional): batch size. Defaults to 64.
            device (str, optional): device to load data. Defaults to 'cuda:0'if torch.cuda.is_available() else 'cpu'.
        """
        super(MatDataset, self).__init__()
        self.device = device
        with open(path, 'rb') as f:
            data = np.load(f)
            self.channel = data['channel']
            self.label = data['label']

    def __len__(self):
        """Get the length of dataset

        Returns:
            int: number of samples in the dataset.
        """
        return len(self.channel)

    def __getitem__(self, idx):
        """Get a sample from dataset

        Args:
            idx (int): index of sample

        Returns:
            torch.Tensor: complex tensor with shape (M, N)
            torch.Tensor: complex tensor with shape (M, N)
        """
        channel = self.channel[idx]
        label = self.label[idx]

        return torch.from_numpy(channel).to(self.device).to(torch.complex64), torch.from_numpy(label).to(self.device).to(torch.complex64)
