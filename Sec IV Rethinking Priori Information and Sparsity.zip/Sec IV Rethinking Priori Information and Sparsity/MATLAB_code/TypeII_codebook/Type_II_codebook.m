%% paramCombination_Rel 17 = 4
function [W_perfect_feed_back, W_BS] = Type_II_codebook(H_DL, feedback_vector, beam, delay, paramCombination_r17, tx_num, CSI_RS, RB_num, Space_vec)
    Table_I =       [1, 3 / 4, 1 / 2;
                    1, 1, 1 / 2; 
                    1, 1, 3 / 4; 
                    1, 1, 1; 
                    2, 1 / 2, 1 / 2; 
                    2, 3 / 4, 1 / 2;
                    2, 1, 1 / 2;
                    2, 1, 3 / 4]; %% paramCombination_rel 17
    Mapping_kp_1 = [
                1 / sqrt(128)
                (1 / 8192)^ (1/4)
                1 / 8
                (1 / 2048)^ (1/4)
                1 / (2 * sqrt(8))
                (1 / 512)^ (1/4)
                1 / 4
                (1 / 128)^ (1/4)
                1 / sqrt(8)
                (1 / 32)^ (1/4)
                1 / 2
                (1 / 8)^ (1/4)
                1 / sqrt(2)
                (1 / 2)^ (1/4)
                1];
    % amplitude quantization: 3 bit
    Mapping_kp_2 = [0
                1 / (8 * sqrt(2))
                1 / 8
                1 / (4 * sqrt(2))
                1 / 4
                1 / (2 * sqrt(2))
                1 / 2
                1 / sqrt(2)
                1]; % 3 bit
    % phase quantization: 4 bit
    Mapping_cphase = (-pi : 2 * pi / 16 : pi)';
    M = Table_I(paramCombination_r17, 1);
    alpha = Table_I(paramCombination_r17, 2);
    beta = Table_I(paramCombination_r17, 3);
    K1 = CSI_RS * alpha;
    L = K1 / 2;
    %% define delay-domain basis
    fft_delay_vec = exp(1i * 2 * pi / RB_num * (0 : RB_num - 1)' * (0 : RB_num - 1))'; 

    %% CSI_RS beamforming
    CSI_RS_BF = zeros(tx_num,RB_num,CSI_RS);
    for i = 1 : CSI_RS
        CSI_RS_BF(:,:,i) = conj(Space_vec(:, beam(i))) * fft_delay_vec(delay(i), :);
    end
    %% Downlink beamforming and UE measurement (replaced by load feedback_vector)
    H_DL_bf_RB = zeros(CSI_RS, RB_num);
    for j = 1 : RB_num
        H_DL_bf_RB(:, j) = squeeze(H_DL(:, j)).' * squeeze(CSI_RS_BF(:, j, :));
    end
    H_DL_bf = sum(H_DL_bf_RB, 2);

    %% SVD decomposition
    W_perfect = conj(feedback_vector);
    W_perfect = W_perfect / norm(W_perfect);
    %% Port selection
    P_contri = abs(W_perfect.').^2;
    P_contri = P_contri(1 : CSI_RS / 2) + P_contri(CSI_RS / 2 + 1 : end);
    [~,Ps] = sort(P_contri, 'descend');
    Ps_index = sort(Ps(1 : L));
    Ps_index = [Ps_index, Ps_index + CSI_RS / 2];
    Ps = zeros(CSI_RS, 1);
    Ps(Ps_index) = W_perfect(Ps_index);
    Wv = Ps;
    W_perfect_feed_back = zeros(tx_num, RB_num);
    for i = 1 : CSI_RS
        W_perfect_feed_back = W_perfect_feed_back + W_perfect(i) * conj(Space_vec(:,beam(i)) * fft_delay_vec(:, delay(i))');
    end
    W_perfect_feed_back = W_perfect_feed_back ./ sqrt(sum(abs(W_perfect_feed_back).^2, 1));
    %% Quantization
    %% Wideband power coefficient
    p1_1 = max(abs(Wv(1 : CSI_RS / 2)));
    p1_2 = max(abs(Wv(CSI_RS / 2 + 1 : end)));
    p1_max = max(p1_1, p1_2);
    p1_1 = p1_1 / p1_max;
    p1_2 = p1_2 / p1_max;
    [~,p_choice_1_1] = min(abs(Mapping_kp_1 - p1_1));
    [~,p_choice_1_2] = min(abs(Mapping_kp_1 - p1_2));
    p1_1 = Mapping_kp_1(p_choice_1_1);
    p1_2 = Mapping_kp_1(p_choice_1_2);
    %% Normalization based on wideband power coefficient
    Wv(1 : CSI_RS / 2) = Wv(1 : CSI_RS / 2) / p1_1;
    Wv(CSI_RS / 2 + 1 : end) = Wv(CSI_RS / 2 + 1 : end) / p1_2;
    %% Narrowband power coefficient
    Wv_amp = abs(Wv);
    p2_max_1 = max(abs(Wv_amp(1 : CSI_RS / 2)));
    p2_max_2 = max(abs(Wv_amp(CSI_RS / 2 + 1 : end)));
    Wv_amp(1 : CSI_RS / 2) = Wv_amp(1 : CSI_RS / 2) / p2_max_1;
    Wv_amp(CSI_RS / 2 + 1 : end) = Wv_amp(CSI_RS / 2 + 1 : end) / p2_max_2;
    [~,amp_choice] = min(abs(Wv_amp - Mapping_kp_2'),[],2);
    Wv_amp = Mapping_kp_2(amp_choice);
    Wv_temp = zeros(CSI_RS, 1);
    Wv_temp(Ps_index) = Wv_amp(Ps_index);
    Wv_amp = Wv_temp;
    %% Narrowband phase coefficient
    Wv_angle = angle(Wv);
    [~,Wv_angle_index] = min(abs(Wv_angle - Mapping_cphase'), [], 2);
    Wv_angle = Mapping_cphase(Wv_angle_index);
    Wv = Wv_amp .* exp(1i * Wv_angle);
    Wv(1:CSI_RS / 2) = Wv(1:CSI_RS / 2) * p1_1;
    Wv(CSI_RS / 2 + 1 : end) = Wv(CSI_RS / 2 + 1 : end) * p1_2;
    %% beamforming recovery
    W_BS = zeros(tx_num, RB_num);
    for i = 1 : CSI_RS
        W_BS = W_BS + Wv(i) * conj(Space_vec(:,beam(i)) * fft_delay_vec(:, delay(i))');
    end
    W_BS = W_BS ./ sqrt(sum(abs(W_BS).^2, 1));
end