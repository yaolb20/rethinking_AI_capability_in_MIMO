import torch
import torch.nn as nn
import math
import random
import collections

alpha = 5.

# stacked sigmoid approximation
class Sigmoid_Approximation(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x):
        ctx.save_for_backward(x)
        return 0.25 * (torch.sign(x) + torch.sign(x - 0.5) + torch.sign(x + 0.5))

    @staticmethod
    def backward(ctx, grad_output):
        x = ctx.saved_tensors
        x = x[0]
        global alpha
        grad1 = 0.5 * alpha * torch.sigmoid(
            alpha * x) * (1 - torch.sigmoid(alpha * x)) * grad_output
        grad2 = 0.5 * alpha * torch.sigmoid(
            alpha * (x - 0.5)) * (1 - torch.sigmoid(alpha * (x - 0.5))) * grad_output
        grad3 = 0.5 * alpha * torch.sigmoid(
            alpha * (x + 0.5)) * (1 - torch.sigmoid(alpha * (x + 0.5))) * grad_output
        grad_x = grad1 + grad2 + grad3
        return grad_x, None

# convolution module
class CB2D(nn.Module):
    def __init__(self, f_i = 128, f_o = 128, k = (3, 3), s = (1, 1), p = (1, 1)):
        super(CB2D, self).__init__()
        self.conv = nn.Conv2d(in_channels = f_i, out_channels = f_o, kernel_size = k, stride = s, padding = p, padding_mode = 'circular')
        self.bn = nn.BatchNorm2d(f_o)
        self.activation = nn.LeakyReLU(.1)

    def forward(self, h):
        h = self.conv(h)
        h = self.bn(h)
        h = self.activation(h)
        return h

# main model
class Model(nn.Module):
    def __init__(self,
                 b = 64,
                 K = 5,
                 N_t = 32, 
                 N_p = 32, 
                 M = 8, 
                 B = 229,
                 device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")):
        super(Model, self).__init__()

        # system parameters
        self.b = b # batch size
        self.K = K # UE number
        self.N_t = N_t # BS antenna number
        self.N_p = N_p # selected port number
        self.M = M # RB number
        self.B = B # feedback bit
        self.Q = 2  # number of quantization bits
        self.device = device
       
        self.qua = Sigmoid_Approximation()

        # Encoding module    
        # FCB1
        self.fc_en1 = nn.Linear(2 * self.N_p, 1024)
        self.bn_en1 = nn.BatchNorm1d(1024)
        self.activation_en1 = nn.LeakyReLU(.3)
        
        # FCB2
        self.fc_en2 = nn.Linear(1024, int(self.B/self.Q))
        self.bn_en2 = nn.BatchNorm1d(int(self.B/self.Q))        
        self.activation_en2 = nn.Tanh()

        # Decoding module
        # FCB 
        self.drop_de = nn.Dropout(0.02)
        self.fc_de = nn.Linear(int(self.B/self.Q), 2 * self.N_p) 

        self.cb1 = CB2D(f_i = 2, f_o = 256, k = (3, 3), s = (1, 1), p = (1, 1))
        self.cb2 = CB2D(f_i = 256, f_o = 512, k = (3, 3), s = (3, 1), p = (1, 1))
        self.cb3 = CB2D(f_i = 512, f_o = 512, k = (3, 3), s = (3, 3), p = (1, 1))
        self.cb4 = CB2D(f_i = 512, f_o = 512, k = (3, 3), s = (3, 3), p = (1, 1))
        self.cb5 = CB2D(f_i = 512, f_o = 512, k = (3, 3), s = (3, 3), p = (1, 1))

        self.drop_out = nn.Dropout(0.02)
        self.fc_out = nn.Linear(512, 2 * self.N_t * self.M)
        
    def forward(self, h, beam_index, delay_index, weight_sum):
        
        # UE side        
        # (b * K, 2 * N_p)
        
        # FCB1
        h = self.fc_en1(h)
        h = self.bn_en1(h)
        h = self.activation_en1(h)
        # h_size = (b * K, 1024)
        
        # FCB2
        h = self.fc_en2(h)
        h = self.bn_en2(h)        
        h = self.activation_en2(h)
        # h_size = (b * K, B/Q)       
        
        # uniform quantization
        h = self.qua.apply(h) # Q bit quantization
        
        # BS side
        
        # FCB
        h_recover = self.drop_de(h)
        h_recover = self.fc_de(h_recover)
        # (b * K, 2 * N_p)
              
        # 2-norm
        h_recover_2 = torch.linalg.norm(h_recover, dim = 1)  # (b * K)
        h_recover = h_recover.permute(1, 0) / h_recover_2
        h_recover = h_recover.permute(1, 0) # (b * K, 2 * N_p)
        
        # fill
        h_recover = h_recover.reshape(h_recover.shape[0], 2, self.N_p) # (b * K, 2, N_p)
        h_recover_r = h_recover[:, 0, :]
        h_recover_i = h_recover[:, 1, :]       
        # (b * K, N_p)
        
        h_recover_r = h_recover_r.reshape(-1)
        h_recover_i = h_recover_i.reshape(-1)
        # (b * K * N_p)
        
        H_recover_r = torch.zeros((self.b * self.K * self.N_t, self.M), device = self.device)
        H_recover_i = torch.zeros((self.b * self.K * self.N_t, self.M), device = self.device)
        # (b * K * N_t, M)
        
        H_recover_r[beam_index.detach(), delay_index.detach()] = h_recover_r
        H_recover_i[beam_index.detach(), delay_index.detach()] = h_recover_i
        
        H_recover_r = H_recover_r.reshape(-1, self.N_t, self.M)
        H_recover_i = H_recover_i.reshape(-1, self.N_t, self.M)
        # (b * K, N_t, M)
        
        H_recover = torch.stack((H_recover_r, H_recover_i), dim = 1) # (b * K, 2, N_t, M)

        '''
        H_recover = h_recover.reshape(h_recover.shape[0], 2, self.N_p)
        H_recover = H_recover.unsqueeze(dim = 3).repeat(1, 1, 1, self.M)
        '''
        
        H_shortcut = H_recover
        
        H_recover = self.cb1(H_recover)
        H_recover = self.cb2(H_recover)
        H_recover = self.cb3(H_recover)
        H_recover = self.cb4(H_recover)
        H_recover = self.cb5(H_recover)
      
        H_recover = nn.AvgPool2d(kernel_size=(H_recover.shape[2], H_recover.shape[3]))(H_recover)
        H_recover = self.drop_out(H_recover.squeeze(dim = 3).squeeze(dim = 2))
        H_recover = self.fc_out(H_recover)
        
        H_recover = H_recover.reshape(H_recover.shape[0], 2, self.N_t, self.M)
        # (b * K, 2, N_t, M)
        
        H_recover = H_recover + weight_sum * H_shortcut
        
        # 2-norm
        H_recover = H_recover.reshape(H_recover.shape[0], -1) # (b * K, 2 * N_t * M)
        H_recover_2 = torch.linalg.norm(H_recover, dim = 1)
        H_recover = H_recover.permute(1, 0) / H_recover_2
        H_recover = H_recover.permute(1, 0)
        
        H_recover = H_recover.reshape(H_recover.shape[0], 2, self.N_t, self.M) # (b * K, 2, N_t, M)
        
        return H_recover
