import torch
import numpy as np
import scipy.io as sio
from dataloader_R17CsiNet import Dataloader
from model_R17CsiNet import Model
import time
import random
import math

# calculate sum rate
def rate_for_multi_UE(EVCSI_matrix_recover, EVCSI_matrix_origin, b, K, N_t, N_p, M, device, sigma):
    P = 0.0399 # transmit power for each user
  
    W_precoding = EVCSI_matrix_recover 
    W_precoding = W_precoding.permute(0, 3, 1, 2) # size = (b, M, K, N_t)
    
    # ZF
    W_ZF = torch.linalg.pinv(W_precoding) # size = (b, M, N_t, K)
    
    # power allocation
    W_ZF = W_ZF.permute(2, 0, 1, 3) / torch.linalg.norm(W_ZF, dim = 2) # size = (N_t, b, M, K)
    
    W_ZF = W_ZF.permute(1, 2, 0, 3) * math.sqrt(P) # (b, M, N_t, K)

    channel = EVCSI_matrix_origin.permute(0, 3, 1, 2) # (b, M, K, N_t)
    
    BS_H_UE = torch.matmul(channel, W_ZF) # size = (b, M, K, K)

    BS_H_UE = torch.abs(BS_H_UE)
    HV = BS_H_UE ** 2
    eff_power = torch.diagonal(HV, offset = 0, dim1 = -2, dim2 = -1) # effective power, size = (b, M, K)
    sum_power = torch.sum(HV, dim = 3) # sum power, size = (b, M, K)

    rate_k = (sum_power + sigma) / (sum_power - eff_power + sigma) # (b, M, K)
    rate_k = torch.log2(rate_k) # (b, M, K)

    sum_rate = torch.sum(rate_k, dim = 2) # (b, M)
     
    return sum_rate

def channel_NMSEloss(h_label, h_recover):
    assert h_label.shape == h_recover.shape, "h_label and h_recover should have the same shape!"   
    # (b, K, N_t, M)
    return torch.mean(torch.linalg.norm((h_label - h_recover), dim = (2, 3)) ** 2 / torch.linalg.norm(h_label, dim = (2, 3)) ** 2, dim = (0, 1))

def channel_CosSimloss(h_label, h_recover):
    # (b, K, N_t, M)
    h_label = h_label.conj()
    cos_sim = torch.mean(torch.abs(torch.sum(h_label * h_recover, dim = (2, 3))) / (torch.linalg.norm(h_label, dim = (2, 3)) * torch.linalg.norm(h_recover, dim = (2, 3))))
    return cos_sim

# evaluation function
def eval(model, loader, b, K, N_t, N_p, M, weight_sum, Mapping_beam, space_vec, fft_delay_vec, device, sigma = 2.2661e-15):
    # reset dataloader
    loader.reset()
    # judge whether dataset is finished
    done = False
    # running loss
    running_NMSE = 0
    running_rate = 0
    running_cossim = 0
    # count batch number
    batch_num = 0

    # evaluate validation set
    while not done:
        basis_angle, basis_delay, Feedback_DL, EVCSI_matrix_origin, label_zp_DL, label_op_DL, beam_index, delay_index, done = loader.next_batch()       
        if done == False:
            batch_num += 1
                   
            # 2-norm
            Feedback_2 = torch.linalg.norm(Feedback_DL, dim = 2)  # (b, K)
            Feedback_DL = Feedback_DL.permute(2, 0, 1) / Feedback_2 # (N_p, b, K)
            Feedback_DL = Feedback_DL.permute(1, 2, 0) # (b, K, N_p)
            
            Feedback_origin = Feedback_DL # (b, K, N_p)
            
            # label_op_DL in angular-delay domain, size = (b, K, N_t, M)
            label_op_DL_2 = torch.linalg.norm(label_op_DL, dim = (2, 3))
            label_op_DL_mse = label_op_DL.permute(2, 3, 0, 1) / label_op_DL_2
            label_op_DL_mse = label_op_DL_mse.permute(2, 3, 0, 1)     
            # (b, K, N_t, M)
            
            Feedback_DL = torch.stack((Feedback_DL.real, Feedback_DL.imag), dim = 2)  # (b, K, 2, N_p)
            Feedback_DL = Feedback_DL.reshape(-1, 2, N_p) # (b * K, 2, N_p)
            Feedback_DL = Feedback_DL.reshape(Feedback_DL.shape[0], -1) # (b * K, 2 * N_p)
                               
            # index regularization        
            beam_index = beam_index.reshape(-1, N_p) # (b * K, N_p)
            delay_index = delay_index.reshape(-1, N_p) # (b * K, N_p)
            
            beam_index = beam_index.reshape(-1) # (b * K * N_p)
            beam_index = beam_index + Mapping_beam                   
            delay_index = delay_index.reshape(-1) # (b * K * N_p)
                     
            EVCSI_matrix_recover = model(h = Feedback_DL, beam_index = beam_index, delay_index = delay_index, weight_sum = weight_sum)
            EVCSI_matrix_recover = EVCSI_matrix_recover.reshape(b, K, 2, N_t, M) # (b, K, 2, N_t, M)
            EVCSI_matrix_recover = torch.complex(EVCSI_matrix_recover[:, :, 0, :, :], EVCSI_matrix_recover[:, :, 1, :, :]) # (b, K, N_t, M)
            
            loss = channel_NMSEloss(h_label = label_op_DL_mse, h_recover = EVCSI_matrix_recover)
            cos_sim = channel_CosSimloss(h_label = label_op_DL_mse, h_recover = EVCSI_matrix_recover)
           
            # (b, K, N_t, M)                
            # angular -> spatial
            EVCSI_matrix_recover = torch.matmul(space_vec, EVCSI_matrix_recover)
            # delay -> frequency
            EVCSI_matrix_recover = torch.matmul(EVCSI_matrix_recover, fft_delay_vec.conj())
            # (b, K, N_t, M)
            rate = torch.mean(rate_for_multi_UE(EVCSI_matrix_recover, EVCSI_matrix_origin, b, K, N_t, N_p, M, device, sigma))
            
            running_NMSE += loss.item()
            running_rate += rate.item()
            running_cossim += cos_sim.item()
        
    # average loss
    NMSE_losses = running_NMSE / batch_num
    rate_losses = running_rate / batch_num
    cossim_losses = running_cossim / batch_num
    # print results
    print("Evaluation NMSE Loss: %.5f" % (NMSE_losses))
    print("Evaluation Rate Loss: %.5f" % (rate_losses))
    print("Evaluation CosSim Loss: %.5f" % (cossim_losses))
    return NMSE_losses, rate_losses, cossim_losses


# main function
# run this file to train and evaluate the model
# OUTPUT: MATLAB data file
# B: feedback bit
def main(training_time = 1, epoch_num = 200, b = 64, B = 229, mu = 0.00025, weight_sum = 1., sigma = 2.2661e-15, lr = 1e-3, minlr = 1e-9):
    # initialize parameters
    version_name = 'OriginalCsiNet_v1(Vector_Output)(M16,B%d,mu%.5f,weight_sum%.4f,lr%.5f,epoch%d,SNR=25dB)' % (B, mu, weight_sum, lr, epoch_num)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(version_name)
    print('device:%s' % device)
    print('batch_size:%d' % b)
    print('sigma:%e' % sigma)
    print('lr and minlr:(%e,%e)'%(lr,minlr))
    
    # system parameters
    b = 32 # batch
    K = 5 # number of ue
    N_t = 32 # number of Tx
    N_p = 32 # number of selected ports
    M = 16 # number of DL RB

    loader = Dataloader(path='../../data/train_25dB', b = b, K = K, N_t = N_t, N_p = N_p, M = M, device = device)
    eval_loader = Dataloader(path='../../data/test_25dB', b = b, K = K, N_t = N_t, N_p = N_p, M = M, device = device)
    
    # loss_train: average of sum loss in training set
    # loss_eval: average of sum loss in validation set
    loss_train = np.zeros((3, training_time, epoch_num))
    loss_eval = np.zeros((3, training_time, epoch_num))
    now_lr = np.zeros((training_time, epoch_num))

    criterion = torch.nn.MSELoss()
    
    # beam_index Mapping
    Mapping_beam = torch.arange(0, b * K, 1, device = device) * N_t # (b * K)
    Mapping_beam = Mapping_beam.unsqueeze(1).repeat(1, N_p)
    Mapping_beam = Mapping_beam.reshape(-1) # (b * K * N_p)
    
    file_name = 'vectors_16.mat' # CSI transformation basis
    basis = sio.loadmat(file_name)
    space_vec = basis['Space_vec']
    fft_delay_vec = basis['fft_delay_vec']
    space_vec = np.complex64(space_vec)
    fft_delay_vec = np.complex64(fft_delay_vec)
    space_vec = torch.from_numpy(space_vec).to(device) # (N_t, N_t)
    fft_delay_vec = torch.from_numpy(fft_delay_vec).to(device) # (M, M)
    space_vec = space_vec.unsqueeze(0).unsqueeze(0) # (1, 1, N_t, N_t)
    fft_delay_vec = fft_delay_vec.unsqueeze(0).unsqueeze(0) # (1, 1, M, M)
        
    # first loop for training times
    for tt in range(training_time):
        print('Train %d times' % (tt))
        # model initialization
        max_rate = 0.
        
        model = Model(b = b, K = K, N_t = N_t, N_p = N_p, M = M, B = B, device = device)
        model.to(device)        
        # Adam optimizer
        optimizer = torch.optim.Adam(model.parameters(), lr)
        # learning rate adaptive decay
        lr_decay = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode = 'min',
            factor = 0.5,
            patience = 3,
            verbose = True,
            threshold = 0.0001,
            threshold_mode = 'rel',
            cooldown = 0,
            min_lr = minlr,
            eps = 1e-10)       
        
        # switch the loss function, where False -> MSE, True -> Mixed
        switch_loss = False
        # second loop for training times      
        for e in range(epoch_num):
            print('Train %d epoch' % (e))
            # reset the dataloader            
            start_time = time.time()           
            loader.reset()
            eval_loader.reset()
            # judge whether data loading is done
            done = False
            # running loss
            running_loss = 0
            MSE_loss = 0.
            Rate_loss = 0.
            # count batch number
            batch_num = 0
            
            now_lr[tt, e] = optimizer.state_dict()['param_groups'][0]['lr']
            print('This epoch lr is %.10f' % (now_lr[tt, e]))
            
            while not done:
                basis_angle, basis_delay, Feedback_DL, EVCSI_matrix_origin, label_zp_DL, label_op_DL, beam_index, delay_index, done = loader.next_batch()     
                if done == False:
                    batch_num += 1
                       
                    # 2-norm
                    Feedback_2 = torch.linalg.norm(Feedback_DL, dim = 2)  # (b, K)
                    Feedback_DL = Feedback_DL.permute(2, 0, 1) / Feedback_2 # (N_p, b, K)
                    Feedback_DL = Feedback_DL.permute(1, 2, 0) # (b, K, N_p)
                    
                    Feedback_origin = Feedback_DL # (b, K, N_p)
                    
                    # label_op_DL in angular-delay domain, size = (b, K, N_t, M)
                    label_op_DL_2 = torch.linalg.norm(label_op_DL, dim = (2, 3))
                    label_op_DL_mse = label_op_DL.permute(2, 3, 0, 1) / label_op_DL_2
                    label_op_DL_mse = label_op_DL_mse.permute(2, 3, 0, 1)              
                    mse1 = torch.stack((label_op_DL_mse.real, label_op_DL_mse.imag), dim = 2)  # (b, K, 2, N_t, M)
                    
                    Feedback_DL = torch.stack((Feedback_DL.real, Feedback_DL.imag), dim = 2)  # (b, K, 2, N_p)
                    Feedback_DL = Feedback_DL.reshape(-1, 2, N_p) # (b * K, 2, N_p)
                    Feedback_DL = Feedback_DL.reshape(Feedback_DL.shape[0], -1) # (b * K, 2 * N_p)
                                       
                    # index regularization        
                    beam_index = beam_index.reshape(-1, N_p) # (b * K, N_p)
                    delay_index = delay_index.reshape(-1, N_p) # (b * K, N_p)
                    
                    beam_index = beam_index.reshape(-1) # (b * K * N_p)
                    beam_index = beam_index + Mapping_beam                   
                    delay_index = delay_index.reshape(-1) # (b * K * N_p)
                             
                    EVCSI_matrix_recover = model(h = Feedback_DL, beam_index = beam_index, delay_index = delay_index, weight_sum = weight_sum)
                    
                    EVCSI_matrix_recover = EVCSI_matrix_recover.reshape(b, K, 2, N_t, M) # (b, K, 2, N_t, M)
                    
                    mse2 = EVCSI_matrix_recover
                    
                    if switch_loss == False:                     
                        loss_mse = criterion(mse1, mse2) # MSE loss
                        
                        loss = loss_mse
                        
                        loss.backward()
                        # parameter optimization
                        optimizer.step()
                        optimizer.zero_grad()
                        running_loss += loss.item()
                        MSE_loss += loss_mse.item()
                        
                    else: 
                        loss_mse = criterion(mse1, mse2) # MSE loss
                        
                        EVCSI_matrix_recover = torch.complex(EVCSI_matrix_recover[:, :, 0, :, :], EVCSI_matrix_recover[:, :, 1, :, :])
                        # (b, K, N_t, M)                
                        # angular -> spatial
                        EVCSI_matrix_recover = torch.matmul(space_vec, EVCSI_matrix_recover)
                        # delay -> frequency
                        EVCSI_matrix_recover = torch.matmul(EVCSI_matrix_recover, fft_delay_vec.conj())
                        # (b, K, N_t, M)
                        
                        loss_nmr = - torch.mean(rate_for_multi_UE(EVCSI_matrix_recover, EVCSI_matrix_origin, b, K, N_t, N_p, M, device, sigma)) / K
                        
                        loss_mixed = loss_mse + loss_nmr * mu
                        
                        loss = loss_mixed
                        loss.backward()
                        # parameter optimization
                        optimizer.step()
                        optimizer.zero_grad()
                        running_loss += loss.item()
                        MSE_loss += loss_mse.item()
                        Rate_loss += loss_nmr.item()


            losses = running_loss / batch_num
            MSE_loss = MSE_loss / batch_num
            Rate_loss = Rate_loss / batch_num

            #print results
            loss_train[0, tt, e] = losses
            loss_train[1, tt, e] = MSE_loss
            loss_train[2, tt, e] = Rate_loss
            print('Training Loss: %.5f' % losses)
            print('Training MSE Loss: %.5f' % MSE_loss)
            print('Training -Rate Loss: %.5f' % Rate_loss)
                        
            # eval model            
            model.eval()
            
            # eval_losses: average loss in evaluation set
            
            NMSE_losses, rate_losses, cossim_losses = eval(model, eval_loader, b, K, N_t, N_p, M, weight_sum, Mapping_beam, space_vec, fft_delay_vec, device, sigma)
            loss_eval[0, tt, e] = NMSE_losses
            loss_eval[1, tt, e] = rate_losses
            loss_eval[2, tt, e] = cossim_losses
            
            # train mode
            model.train()
                       
            # switch the loss function
            if e >= 80 and switch_loss == False:
                switch_loss = True
                print('Now, switch loss function from MSE to Mixed!')
                
            # learning rate decay, when in the mixed loss function  
    
            if switch_loss == True:
                lr_decay.step(-rate_losses)
                                   
            # save model            
            if rate_losses > max_rate:
                max_rate = rate_losses
                model_name = version_name + '.pkl'
                torch.save(model.state_dict(), model_name)
            
            # save plot
            mat_name = version_name + '.mat'
            sio.savemat(mat_name, {
                'loss_train': loss_train,
                'loss_eval': loss_eval,
                'now_lr': now_lr           
            })
            
            print('This epoch takes %.1f s' % (time.time() - start_time))



if __name__ == '__main__':
    main()