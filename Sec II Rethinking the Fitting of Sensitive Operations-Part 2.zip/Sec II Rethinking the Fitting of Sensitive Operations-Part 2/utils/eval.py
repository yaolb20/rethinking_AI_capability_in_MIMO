'''
 @ File: eval.py
 @ Time: (UTC+8) 2023/11/03 16:49:02
 @ Description: Evaluate the model
'''
import torch
from utils.system_rate import system_rate


def eval(model, test_loader):
    """Evaluate the model

    Args:
        model (torch.nn.Module): the model to be evaluated
        test_loader (torch.utils.data.DataLoader): dataloader for testing

    Returns:
        float: average loss
    """

    model.eval()
    running_loss = 0
    with torch.no_grad():
        for _, (channel, channel_noise) in enumerate(test_loader):
            # normalize the CSI matrix by each UE
            channel_noise = channel_noise / \
                torch.linalg.vector_norm(channel_noise, dim=-1, keepdim=True)
            output = model(channel_noise)
            loss = - system_rate(channel, output)
            running_loss += loss.item()
    return running_loss / len(test_loader)
