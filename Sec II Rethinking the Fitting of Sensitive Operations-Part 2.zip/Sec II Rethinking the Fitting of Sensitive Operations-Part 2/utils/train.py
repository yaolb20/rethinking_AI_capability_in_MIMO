'''
 @ File: train.py
 @ Time: (UTC+8) 2023/11/03 16:39:07
 @ Description: Train the network for one epoch
'''
import torch
from utils.system_rate import system_rate


def train(model, train_loader, optimizer):
    """Train the model for one epoch

    Args:
        model (torch.nn.Module): the model to be trained
        train_loader (torch.utils.data.DataLoader): dataloader for training
        optimizer (torch.optim): optimizer

    Returns:
        float: average loss
    """

    model.train()
    running_loss = 0
    for _, (channel, channel_noise) in enumerate(train_loader):
        # normalize the CSI matrix by each UE
        channel_noise = channel_noise / \
            torch.linalg.vector_norm(channel_noise, dim=-1, keepdim=True)
        optimizer.zero_grad()
        output = model(channel_noise)
        loss = - system_rate(channel, output)
        loss.backward()
        optimizer.step()
        running_loss += loss.item()
    return running_loss / len(train_loader)
