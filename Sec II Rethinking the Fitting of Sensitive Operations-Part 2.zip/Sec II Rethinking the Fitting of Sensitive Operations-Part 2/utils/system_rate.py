'''
 @ File: system_rate.py
 @ Time: (UTC+8) 2023/11/07 20:58:19
 @ Description: calculate the system rate
'''
import torch
import math


def system_rate(H, V):
    """Calculate the system rate

    Args:
        H (torch.Tensor): channel, complex tensor with shape (batch, N, M)
        V (torch.Tensor): precoding matrix complex tensor with shape (batch, M, N)

    Returns:
        float: system rate
    """

    P = 20000 # transmit power
    N = H.shape[1] # UE number
    sigma = 2.26e-10 # noise power

    V = V / torch.linalg.vector_norm(V, dim=1, keepdims=True) * math.sqrt(P/N) # normalize the precoding matrix to satisfy the power constraint
    HV = torch.matmul(H, V)
    HV = torch.abs(HV)**2 # channel power gain
    power = torch.diagonal(HV, dim1=-2, dim2=-1) # power of each UE
    interference = HV - torch.diag_embed(power) 
    interference = torch.sum(interference, dim=-1) # interference power
    rate = torch.log2(1 + power / (interference + sigma)) # rate of each UE
    rate = torch.sum(rate, dim=-1) # sum rate of all UEs
    rate = torch.mean(rate)
    return rate
