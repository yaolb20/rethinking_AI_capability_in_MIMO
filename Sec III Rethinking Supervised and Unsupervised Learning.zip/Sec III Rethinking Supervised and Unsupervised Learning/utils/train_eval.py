'''
 @ File: train_eval.py
 @ Time: (UTC+8) 2023/08/21 13:02:18
 @ Description: Train the model and evaluate it 10 times in each epoch.
'''
import torch
import numpy as np
from utils.loss.rate_for_multi_UE import rate_for_multi_UE
from utils.eval import eval


def train_eval(model, train_loader, eval_loader, optimizer, weight, sigma=2.26e-10, use_fused_loss=True):
    """train the model for one epoch and evaluate it 10 times during the training process

    Args:
        model (Model): model
        train_loader (Dataloader): dataloader for training
        eval_loader (Dataloader): dataloader for evaluation
        optimizer (torch.optim): optimizer
        weight (int): weight to balance L1 loss and rate loss
        sigma (float, optional): amplitude of additive gauss noise. Defaults to 2.26e-10.
        use_fused_loss (bool, optional): whether to use fused loss. Defaults to True.

    Returns:
        avg_loss (float): average loss of the epoch
        loss_eval (np.array): loss of the evaluation set in each epoch
    """
    running_loss = 0
    MSEloss_func = torch.nn.MSELoss()
    eval_loop = round(len(train_loader) / 10)  # the loop to evaluate the model, len(train_loader) = 1600
    loss_eval = np.zeros((3, 8, 10)) # 3: NMSE, rate, cossim; 8: 8 RBs; 1: 1 training time; 10: 10 times eval in each epoch

    for batch_idx, channel_load in enumerate(train_loader):
        model.train()
        # split the CSI into uplink and downlink
        # (batch_size, 5, 32, 8)
        channel_uplink = channel_load[:, 
                                      :, 0: channel_load.shape[3] // 2]
        channel_downlink = channel_load[:, :, :, channel_load.shape[3] //
                                        2: channel_load.shape[3]].permute(0, 1, 3, 2)  # (batch_size, 5, 8, 32)
        channel_downlink_unnorm = channel_downlink.permute(
            2, 0, 1, 3)  # (8, batch_size, 5, 32)

        # normalize the downlink channel of each user
        max_channel = torch.amax(torch.abs(channel_downlink.reshape(channel_downlink.shape[0],
                                                                    channel_downlink.shape[1], -1)), dim=2)  # the maximun channel element of each user in shape (batch, 5(num_UE))
        # (batch, 5(num_UE), 8(num_RB)*32(BS antennas))
        channel_downlink = channel_downlink.reshape(
            channel_downlink.shape[0], channel_downlink.shape[1], -1)
        # (8(num_RB)*32(BS antennas), batch, 5(num_UE))
        channel_downlink = channel_downlink.permute(2, 0, 1) / max_channel
        # (batch, 5(num_UE), 8(num_RB)*32(BS antennas))
        channel_downlink = channel_downlink.permute(1, 2, 0)
        # (batch, 5(num_UE)*8(num_RB), 32(BS antennas))
        channel_downlink = channel_downlink.reshape(
            channel_downlink.shape[0], channel_downlink.shape[1] * channel_load.shape[3] // 2, channel_load.shape[2])
        # (batch, 2, 5(num_UE)*8(num_RB), 32(BS antennas))
        channel_downlink = torch.stack(
            (channel_downlink.real, channel_downlink.imag), dim=1)

        # pass the uplink channel through the network
        channel_predict = model(channel_uplink)  # (batch, 2, 5*8, 32)

        # calculate the MSE loss and rate loss
        MSEloss = MSEloss_func(channel_predict, channel_downlink)  # MSE loss
        # recover the complex matrix
        channel_predict = channel_predict.reshape(
            channel_load.shape[0], 2, channel_load.shape[1], channel_load.shape[3] // 2, channel_load.shape[2]).permute(3, 0, 1, 2, 4)  # (8, batch, 2, 5, 32)
        channel_predict = torch.complex(
            channel_predict[:, :, 0, :, :], channel_predict[:, :, 1, :, :])  # (8, batch, 5, 32)
        # calculate the rate loss
        rate_loss = - torch.mean(rate_for_multi_UE(channel_predict,
                                                   channel_downlink_unnorm, sigma))  # rate loss
        
        # control the type of loss for comparison between different loss functions
        if use_fused_loss:
            loss = MSEloss * weight + rate_loss
        else:
            loss = MSEloss

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
        running_loss += loss.item()
        # evaluate the model
        if (batch_idx + 1) % eval_loop == 0:
            NMSE_loss, rate_loss, cossim_loss = eval(
                model, eval_loader, sigma)
            loss_eval[0, :, batch_idx // eval_loop] = NMSE_loss
            loss_eval[1, :, batch_idx // eval_loop] = rate_loss
            loss_eval[2, :, batch_idx // eval_loop] = cossim_loss

    avg_loss = running_loss / len(train_loader)

    return avg_loss, loss_eval
