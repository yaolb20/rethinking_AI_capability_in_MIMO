This is the source code of Section III: Rethinking Supervised and Unsupervised Learning
1. Due to storage restriction of Github, datasets, checkpoints and simulation records can be downloaded from Tsinghua Cloud:
https://cloud.tsinghua.edu.cn/d/7ada451e1d6c462f8555/
2. The folder is free to use, including dataset utilization, simulation result reproduction, model improvement, etc.
3. For academic use, please cite the reference below:
K. Ma, L. Yao, et al., Rethinking the Capabilities of Deep Learning in MIMO Systems: Case Studies and Opportunities, submitted to IEEE, to be uploaded in Arxiv.
4. Run `halving.py` to optimize the weight of the fused loss function by successive halving algorithm. 
Run `main.py` to train and evaluate the model. 
The loss function type could be set by modifying the corresponding lines in `main.py`. 
Run `fig4.m` to generate figure 4.